import React from 'react';

import './App.css';
function Imagen() {

    return (
         <h1>hola </h1>
    )

};



export default Imagen;